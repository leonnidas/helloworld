default_app_config = 'course_discovery.apps.course_metadata.apps.CourseMetadataConfig'
