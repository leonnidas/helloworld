JSON = 'application/json'
JPEG = 'image/jpeg'
